-- Run once against your cloud Postgres (Neon / Supabase / RDS / Cloud SQL).
-- Spark overwrites these tables with TRUNCATE, so the schema and indexes persist.

CREATE TABLE IF NOT EXISTS listings_scored (
  listing_id    text PRIMARY KEY,
  title         text,
  make          text,
  family        text,
  model_year    int,
  city          text,
  price         bigint,            -- NULL = "call for price"
  mileage       bigint,
  fuel          text,
  assembly      text,
  engine_cc     int,
  post_date     date,
  fair_price    bigint,
  fair_low      bigint,            -- p25 of comparable listings
  fair_high     bigint,            -- p75 of comparable listings
  deal_ratio    double precision,  -- price / fair_price
  deal_label    text,
  comp_level    int,               -- 1 = most specific comparable group, 4 = broadest
  comp_n        bigint,            -- listings in that group
  confidence    text,              -- high | medium | low | none
  flags         text NOT NULL DEFAULT '',   -- comma separated
  risk_score    int  NOT NULL DEFAULT 0,
  risk_level    text NOT NULL DEFAULT 'none',
  repost_count  int  NOT NULL DEFAULT 0,
  source        text NOT NULL DEFAULT 'batch',   -- batch | stream
  scored_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_ls_risk   ON listings_scored (risk_score DESC);
CREATE INDEX IF NOT EXISTS ix_ls_family ON listings_scored (lower(make), lower(family));
CREATE INDEX IF NOT EXISTS ix_ls_city   ON listings_scored (city);

-- Staging table used by the streaming job for idempotent upserts.
CREATE UNLOGGED TABLE IF NOT EXISTS stg_listings_scored (LIKE listings_scored INCLUDING DEFAULTS);

CREATE TABLE IF NOT EXISTS comps (
  cohort_key     text PRIMARY KEY,   -- "<level>|<make>|<family>[|<year>|<assembly>|<fuel>]" (lower-case)
  level          int NOT NULL,
  make           text,
  family         text,
  model_year     int,                -- only set for levels 1-2
  n              bigint,
  p25            bigint,
  median_price   bigint,
  p75            bigint,
  median_mileage bigint
);
CREATE INDEX IF NOT EXISTS ix_comps_family ON comps (level, lower(make), lower(family));

CREATE TABLE IF NOT EXISTS city_index (
  city         text,
  make         text,                 -- * = all makes
  n            bigint,
  price_index  double precision,     -- median(price / fair price); 1.00 = market
  PRIMARY KEY (city, make)
);

-- ---------------------------------------------------------------------------------------------
-- AutoVal-Intel additions (pipeline outputs, ML artefacts, insights)
-- ---------------------------------------------------------------------------------------------

-- Step 3: the cleaned vehicle dataset
CREATE TABLE IF NOT EXISTS listings_clean (
  listing_id text PRIMARY KEY, title text, make text, family text, model_year int, city text,
  price bigint, mileage bigint, fuel text, assembly text, engine_cc int, post_date date,
  age int, repost_count int
);

-- Step 1: data-quality report, and a log of the last pipeline run
CREATE TABLE IF NOT EXISTS data_quality (check_name text PRIMARY KEY, n bigint, detail text);
CREATE TABLE IF NOT EXISTS pipeline_runs (step int PRIMARY KEY, stage text, row_count bigint, seconds double precision);

-- Step 4/5: feature statistics and the exported models (trees as JSON, metrics as JSON)
CREATE TABLE IF NOT EXISTS enc_stats (
  kind text, make text, family text, n bigint, sum_log_price double precision,
  median_engine_cc bigint, median_mileage bigint, brand_tier int,
  PRIMARY KEY (kind, make, family)
);
CREATE TABLE IF NOT EXISTS ml_models (
  name text PRIMARY KEY, model_json text, metrics text, trained_at timestamptz NOT NULL DEFAULT now()
);

-- Step 6: market insights
CREATE TABLE IF NOT EXISTS depreciation (
  make text, family text,            -- family = '*' means the whole make
  age int, n bigint, p25 bigint, median_price bigint, p75 bigint,
  dep_rate double precision,         -- share of value lost versus one year younger cars
  retained_pct double precision,     -- median price as % of the youngest age group
  PRIMARY KEY (make, family, age)
);
CREATE TABLE IF NOT EXISTS resale_windows (
  make text, family text, n bigint,
  window_start_age int, window_end_age int, window_avg_dep_rate double precision,
  steepest_age int, steepest_rate double precision,
  PRIMARY KEY (make, family)
);
CREATE TABLE IF NOT EXISTS market_segments (
  make text, family text, n bigint, p25 bigint, median_price bigint, p75 bigint,
  spread_ratio double precision, share_pct double precision, inventory_level text,
  PRIMARY KEY (make, family)
);
CREATE TABLE IF NOT EXISTS brand_summary (
  make text PRIMARY KEY, n bigint, median_price bigint, median_age bigint, brand_tier int, avg_dep_rate double precision
);

-- Car finder map
CREATE TABLE IF NOT EXISTS city_geo (city text PRIMARY KEY, lat double precision, lon double precision);
