'use strict';
// Pure functions (no I/O) so they can be unit-tested. They mirror spark/src/main/scala/pw/{Comps,Scoring,Clean}.scala.
// If you change a key format, threshold or label there, change it here too.

const crypto = require('crypto');

const norm = (s) => String(s || '').trim().replace(/\s+/g, ' ');

/** Cohort keys, most specific (level 1) to broadest (level 4). Same format as Comps.key in Spark. */
function cohortKeys({ make, family, year, assembly, fuel }) {
  const mk = norm(make).toLowerCase();
  const fm = norm(family).toLowerCase();
  const base = (l) => `${l}|${mk}|${fm}`;
  const band = Math.floor(year / 3) * 3;
  return [
    { level: 1, key: `${base(1)}|${year}|${assembly || '*'}|${fuel || '*'}` },
    { level: 2, key: `${base(2)}|${year}` },
    { level: 3, key: `${base(3)}|b${band}` },
    { level: 4, key: base(4) },
  ];
}

/** Same thresholds as Scoring.scala (deal_label). */
function dealLabel(price, fair) {
  if (price == null || price <= 0) return 'price_on_call';
  if (!fair) return 'unrated';
  const r = price / fair;
  if (r < 0.55) return 'too_good_to_be_true';
  if (r < 0.85) return 'great_deal';
  if (r < 0.95) return 'good_deal';
  if (r <= 1.10) return 'fair';
  if (r <= 1.25) return 'high';
  return 'overpriced';
}

const CONFIDENCE = { 1: 'high', 2: 'medium', 3: 'medium', 4: 'low' };

/** Pick the most specific comps row with enough listings. rows come from the comps table. */
function chooseComps(rows, minN) {
  return rows
    .filter((r) => Number(r.n) >= minN)
    .sort((a, b) => a.level - b.level)[0] || null;
}

function estimate(row, askingPrice) {
  if (!row) return { available: false, confidence: 'none' };
  const fair = Number(row.median_price);
  const asking = askingPrice > 0 ? Number(askingPrice) : null;
  return {
    available: true,
    fair_price: fair,
    low: Number(row.p25),
    high: Number(row.p75),
    comp_level: row.level,
    comp_n: Number(row.n),
    comp_median_mileage: row.median_mileage == null ? null : Number(row.median_mileage),
    confidence: CONFIDENCE[row.level],
    asking_price: asking,
    ratio: asking ? asking / fair : null,
    label: asking ? dealLabel(asking, fair) : null,   // no asking price -> nothing to judge
  };
}

/** Same fingerprint as Clean.scala listing_id (post_date excluded, so re-posts collide). */
function listingId({ title, price, city, mileage }) {
  const t = norm(title).toLowerCase();
  const p = price > 0 ? String(Math.trunc(price)) : '0';
  const c = String(city || '').trim().toLowerCase();
  return crypto.createHash('sha256').update(`${t}|${p}|${c}|${Math.trunc(mileage)}`).digest('hex');
}

/** Validate a submitted listing. Returns { ok, errors, value }. */
function validateListing(b) {
  const errors = [];
  const year = Number(b.year), mileage = Number(b.mileage);
  const price = b.price === '' || b.price == null ? 0 : Number(b.price);
  if (!norm(b.make)) errors.push('make is required');
  if (!norm(b.family)) errors.push('family is required');
  if (!Number.isInteger(year) || year < 1950 || year > new Date().getFullYear() + 1) errors.push('year is out of range');
  if (!Number.isFinite(mileage) || mileage < 0) errors.push('mileage must be a non-negative number');
  if (!Number.isFinite(price) || price < 0) errors.push('price must be a non-negative number');
  if (!norm(b.city)) errors.push('city is required');
  return {
    ok: errors.length === 0,
    errors,
    value: errors.length ? null : {
      make: norm(b.make), family: norm(b.family), variant: norm(b.variant), year,
      mileage: Math.trunc(mileage), price: Math.trunc(price), city: norm(b.city),
      fuel: b.fuel || null, assembly: b.assembly || null,
      engine_cc: b.engine_cc ? Math.trunc(Number(b.engine_cc)) : null,
    },
  };
}

/** Event in the shape Clean.eventSchema expects. */
function toEvent(v) {
  return {
    title: [v.make, v.family, v.variant, v.year].filter(Boolean).join(' '),
    price: v.price, city: v.city, model: v.year, mileage: v.mileage,
    fuel_type: v.fuel, assembly: v.assembly, engine_capacity: v.engine_cc,
    post_date: new Date().toISOString().slice(0, 10),
  };
}

module.exports = { cohortKeys, dealLabel, chooseComps, estimate, listingId, validateListing, toEvent };
