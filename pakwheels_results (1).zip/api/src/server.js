'use strict';
const express = require('express');
const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const P = require('./pricing');
const ML = require('./ml');

const PORT = Number(process.env.PORT || 3000);
const MIN_COMPS = Number(process.env.MIN_COMPS || 8);          // keep equal to Spark's MIN_COMPS
const INCOMING_DIR = process.env.INCOMING_DIR || path.join(__dirname, '..', '..', 'incoming');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.PGSSL === 'false' ? false : { rejectUnauthorized: false },
  max: 5,
});
const q = (text, params) => pool.query(text, params).then((r) => r.rows);
const lc = (s) => String(s || '').trim().replace(/\s+/g, ' ').toLowerCase();

const app = express();
app.use(express.json({ limit: '50kb' }));
app.use(express.static(path.join(__dirname, '..', '..', 'web')));

// Thrown errors become 500s instead of crashing the process.
const route = (fn) => (req, res) => fn(req, res).catch((e) => {
  console.error(e);
  res.status(500).json({ error: 'internal_error' });
});

// ---------------------------------------------------------------------------------------------
// Basics
// ---------------------------------------------------------------------------------------------
app.get('/api/health', route(async (_req, res) => {
  await q('SELECT 1');
  res.json({ ok: true });
}));

app.get('/api/meta', route(async (_req, res) => {
  const [m] = await q(`SELECT count(*)::int AS total, min(post_date) AS from_date, max(post_date) AS to_date,
      count(*) FILTER (WHERE risk_level IN ('high','medium'))::int AS flagged
      FROM listings_scored WHERE source = 'batch'`);
  const makes = await q(`SELECT make, count(*)::int AS n FROM listings_scored
      GROUP BY make HAVING count(*) >= 20 ORDER BY n DESC`);
  const cities = await q(`SELECT city, count(*)::int AS n FROM listings_scored
      GROUP BY city HAVING count(*) >= 100 ORDER BY n DESC`);
  const [mdl] = await q(`SELECT trained_at FROM ml_models WHERE name = 'price_regressor'`);
  res.json({ ...m, makes, cities, model_trained_at: mdl ? mdl.trained_at : null,
    note: 'Prices are asking prices from a snapshot of PakWheels listings, not current market prices.' });
}));

app.get('/api/families', route(async (req, res) => {
  const rows = await q(`SELECT family, count(*)::int AS n FROM listings_scored
      WHERE lower(make) = lower($1) GROUP BY family HAVING count(*) >= $2 ORDER BY n DESC`,
  [String(req.query.make || ''), MIN_COMPS]);
  res.json(rows);
}));

// ---------------------------------------------------------------------------------------------
// Price: comparable listings (always available) and the Spark MLlib model (when trained)
// ---------------------------------------------------------------------------------------------
async function priceFor(v, askingPrice) {
  const keys = P.cohortKeys({ make: v.make, family: v.family, year: v.year, assembly: v.assembly, fuel: v.fuel });
  const rows = await q('SELECT * FROM comps WHERE cohort_key = ANY($1)', [keys.map((k) => k.key)]);
  const est = P.estimate(P.chooseComps(rows, MIN_COMPS), askingPrice);
  const [ci] = await q(`SELECT price_index, n FROM city_index
      WHERE lower(city) = lower($1) AND make = '*'`, [v.city || '']);
  if (ci) est.city_index = { value: Number(ci.price_index), n: Number(ci.n) };
  return est;
}

// The exported model is a few hundred KB, so keep it in memory and refresh every 5 minutes.
let modelCache = { at: 0, model: null, metrics: null };
async function getModel() {
  if (Date.now() - modelCache.at < 5 * 60 * 1000) return modelCache;
  const [r] = await q(`SELECT model_json, metrics FROM ml_models WHERE name = 'price_regressor'`);
  let model = null, metrics = null;
  try {
    if (r && r.model_json) { model = JSON.parse(r.model_json); metrics = JSON.parse(r.metrics); }
  } catch (e) { console.error('could not parse model', e); }
  modelCache = { at: Date.now(), model, metrics };
  return modelCache;
}

app.post('/api/price/predict', route(async (req, res) => {
  const b = req.body || {};
  const v = P.validateListing({ ...b, mileage: b.mileage ?? 0, city: b.city || 'n/a' });
  if (!v.ok) return res.status(400).json({ errors: v.errors });
  const val = { ...v.value, city: b.city || '' };

  const [comps, { model, metrics }] = await Promise.all([priceFor(val, val.price), getModel()]);

  let ml = null;
  if (model) {
    const rows = await q(`SELECT * FROM enc_stats WHERE kind = 'global'
        OR (kind = 'make' AND make = $1) OR (kind = 'family' AND make = $1 AND family = $2)`,
    [lc(val.make), lc(val.family)]);
    const stats = {
      global: rows.find((r) => r.kind === 'global'),
      make: rows.find((r) => r.kind === 'make') || null,
      family: rows.find((r) => r.kind === 'family') || null,
    };
    if (stats.global) {
      const p = ML.predict(model, {
        make: val.make, family: val.family, year: val.year, mileage: Number(b.mileage) || 0,
        engine_cc: val.engine_cc, fuel: val.fuel, assembly: val.assembly }, stats);
      const chosen = metrics && metrics.holdout && metrics.holdout.candidates.find((c) => c.name === metrics.chosen);
      ml = { price: p.price, confidence: p.confidence, model: metrics ? metrics.chosen : null,
        typical_error: chosen ? chosen.mdape : null, p90_error: chosen ? chosen.p90_ape : null,
        mileage_used: p.used.mileage, engine_used: p.used.engine,
        mileage_assumed: !(Number(b.mileage) > 0), based_on_models: p.used.family_n };
    }
  }

  const source = ML.pickHeadline(metrics, !!ml, !!comps.available);
  const fair = source === 'ml' ? (ml && ml.price) : (comps.available ? comps.fair_price : null);
  const asking = val.price > 0 ? val.price : null;
  res.json({
    headline: fair ? { source, fair_price: fair, asking_price: asking,
      ratio: asking ? asking / fair : null, label: asking ? P.dealLabel(asking, fair) : null } : null,
    ml, comps,
    baseline_error: metrics && metrics.holdout ? metrics.holdout.baseline_comps.mdape : null,
  });
}));

// Comparable-listings estimate only (kept for simple clients).
app.post('/api/price/estimate', route(async (req, res) => {
  const b = req.body || {};
  const v = P.validateListing({ ...b, mileage: b.mileage ?? 0, city: b.city || 'n/a' });
  if (!v.ok) return res.status(400).json({ errors: v.errors });
  res.json(await priceFor({ ...v.value, city: b.city || '' }, v.value.price));
}));

// ---------------------------------------------------------------------------------------------
// Car finder: where can I find this car, and where is it cheapest?
// ---------------------------------------------------------------------------------------------
function finderFilters(qs) {
  const where = ['l.price IS NOT NULL'];
  const params = [];
  const add = (sql, v) => { params.push(v); where.push(sql.replace('?', '$' + params.length)); };
  const num = (v) => (v !== undefined && v !== '' && Number.isFinite(Number(v)) ? Number(v) : null);
  if (qs.make) add('lower(l.make) = lower(?)', String(qs.make));
  if (qs.family) add('lower(l.family) = lower(?)', String(qs.family));
  if (num(qs.min_year) != null) add('l.model_year >= ?', num(qs.min_year));
  if (num(qs.max_year) != null) add('l.model_year <= ?', num(qs.max_year));
  if (num(qs.min_price) != null) add('l.price >= ?', num(qs.min_price));
  if (num(qs.max_price) != null) add('l.price <= ?', num(qs.max_price));
  if (num(qs.max_mileage) != null) add('l.mileage <= ?', num(qs.max_mileage));
  if (qs.fuel) add('l.fuel = ?', String(qs.fuel));
  if (qs.assembly) add('l.assembly = ?', String(qs.assembly));
  if (qs.city) add('lower(l.city) = lower(?)', String(qs.city));
  if (qs.safe !== '0') where.push('l.risk_score < 20');          // hide listings with risk flags unless asked
  return { where, params };
}

const SORTS = {
  deal: 'l.deal_ratio ASC NULLS LAST', price: 'l.price ASC',
  year: 'l.model_year DESC', mileage: 'l.mileage ASC NULLS LAST',
};

app.get('/api/finder', route(async (req, res) => {
  const { where, params } = finderFilters(req.query);
  const sort = SORTS[req.query.sort] ? req.query.sort : 'deal';
  if (sort === 'deal') where.push('l.deal_ratio IS NOT NULL');
  const limit = Math.max(1, Math.min(100, Number(req.query.limit || 30)));
  params.push(limit);
  const rows = await q(`SELECT l.listing_id, l.title, l.city, l.price, l.mileage, l.model_year, l.fuel, l.assembly,
      l.fair_price, l.deal_ratio, l.deal_label, l.confidence, l.risk_level, g.lat, g.lon
      FROM listings_scored l LEFT JOIN city_geo g ON lower(g.city) = lower(l.city)
      WHERE ${where.join(' AND ')} ORDER BY ${SORTS[sort]} LIMIT $${params.length}`, params);
  res.json(rows);
}));

app.get('/api/finder/cities', route(async (req, res) => {
  const { where, params } = finderFilters({ ...req.query, city: '' });   // the map always shows every city
  const rows = await q(`SELECT l.city, count(*)::int AS n, min(l.price)::bigint AS min_price,
      (percentile_cont(0.5) WITHIN GROUP (ORDER BY l.price))::bigint AS median_price, g.lat, g.lon
      FROM listings_scored l LEFT JOIN city_geo g ON lower(g.city) = lower(l.city)
      WHERE ${where.join(' AND ')} GROUP BY l.city, g.lat, g.lon ORDER BY n DESC LIMIT 60`, params);
  res.json(rows);
}));

// ---------------------------------------------------------------------------------------------
// Insights from the Spark market-insights stage
// ---------------------------------------------------------------------------------------------
app.get('/api/insights/depreciation', route(async (req, res) => {
  const rows = await q(`SELECT age, n::int, p25::bigint, median_price::bigint, p75::bigint, dep_rate, retained_pct
      FROM depreciation WHERE lower(make) = lower($1) AND lower(family) = lower($2) ORDER BY age`,
  [String(req.query.make || ''), String(req.query.family || '*')]);
  res.json(rows);
}));

app.get('/api/insights/resale', route(async (req, res) => {
  const [row] = await q(`SELECT * FROM resale_windows WHERE lower(make) = lower($1) AND lower(family) = lower($2)`,
    [String(req.query.make || ''), String(req.query.family || '*')]);
  res.json(row || null);
}));

app.get('/api/insights/brands', route(async (_req, res) => {
  const rows = await q(`SELECT b.make, b.n::int, b.median_price::bigint, b.median_age::int, b.brand_tier, b.avg_dep_rate,
      r.window_start_age, r.window_end_age
      FROM brand_summary b LEFT JOIN resale_windows r ON lower(r.make) = lower(b.make) AND r.family = '*'
      ORDER BY b.n DESC LIMIT 25`);
  res.json(rows);
}));

app.get('/api/insights/segments', route(async (req, res) => {
  const limit = Math.max(1, Math.min(50, Number(req.query.limit || 20)));
  const rows = await q(`SELECT make, family, n::int, median_price::bigint, spread_ratio, share_pct, inventory_level
      FROM market_segments ORDER BY n DESC LIMIT $1`, [limit]);
  res.json(rows);
}));

app.get('/api/city-index', route(async (req, res) => {
  const make = req.query.make ? String(req.query.make) : '*';
  const rows = await q(`SELECT city, n::int, price_index FROM city_index
      WHERE lower(make) = lower($1) ORDER BY price_index DESC`, [make]);
  res.json(rows);
}));

app.get('/api/market/supply', route(async (req, res) => {
  const by = req.query.by === 'make' ? 'make' : 'city';      // whitelist: never interpolate user input
  const rows = await q(`SELECT ${by} AS label, count(*)::int AS n,
      (percentile_cont(0.5) WITHIN GROUP (ORDER BY price))::bigint AS median_price
      FROM listings_scored WHERE price IS NOT NULL AND source = 'batch'
      GROUP BY ${by} ORDER BY n DESC LIMIT 15`);
  res.json(rows);
}));

// ---------------------------------------------------------------------------------------------
// Pipeline and model report (for the "Pipeline & Models" tab)
// ---------------------------------------------------------------------------------------------
app.get('/api/report', route(async (_req, res) => {
  const models = (await q('SELECT name, metrics, trained_at FROM ml_models ORDER BY name')).map((m) => {
    let metrics = null;
    try { metrics = JSON.parse(m.metrics); } catch (_) { /* leave null */ }
    return { name: m.name, trained_at: m.trained_at, metrics };
  });
  const quality = await q('SELECT check_name, n::bigint, detail FROM data_quality ORDER BY check_name');
  const runs = await q('SELECT step, stage, row_count::bigint, seconds FROM pipeline_runs ORDER BY step');
  res.json({ models, quality, runs });
}));

// ---------------------------------------------------------------------------------------------
// Live listing screening (hand-off to Spark Structured Streaming)
// ---------------------------------------------------------------------------------------------
app.get('/api/moderation', route(async (req, res) => {
  const minRisk = Math.max(0, Math.min(100, Number(req.query.min_risk || 20)));
  const limit = Math.max(1, Math.min(200, Number(req.query.limit || 50)));
  const rows = await q(`SELECT listing_id, title, city, price, fair_price, deal_ratio, deal_label, flags,
      risk_score, risk_level, repost_count, source, scored_at
      FROM listings_scored WHERE risk_score >= $1
      ORDER BY (source = 'stream') DESC, scored_at DESC, risk_score DESC LIMIT $2`, [minRisk, limit]);
  res.json(rows);
}));

app.get('/api/moderation/summary', route(async (_req, res) => {
  const rows = await q(`SELECT f AS flag, count(*)::int AS n
      FROM listings_scored, unnest(string_to_array(flags, ',')) AS f
      WHERE flags <> '' GROUP BY f ORDER BY n DESC`);
  res.json(rows);
}));

// New listing: answer instantly with a price estimate, and queue the event for Spark Structured Streaming,
// which persists the full set of flags to listings_scored within a few seconds.
app.post('/api/listings', route(async (req, res) => {
  const v = P.validateListing(req.body || {});
  if (!v.ok) return res.status(400).json({ errors: v.errors });

  const event = P.toEvent(v.value);
  const id = P.listingId(event);
  const estimate = await priceFor(v.value, v.value.price);

  fs.mkdirSync(INCOMING_DIR, { recursive: true });
  const tmp = path.join(INCOMING_DIR, `.${crypto.randomUUID()}.tmp`);   // Spark ignores dot-files
  fs.writeFileSync(tmp, JSON.stringify(event) + '\n');
  fs.renameSync(tmp, path.join(INCOMING_DIR, `${Date.now()}-${id.slice(0, 8)}.json`)); // atomic publish

  res.status(202).json({ listing_id: id, status: 'queued', estimate });
}));

app.get('/api/listings/:id', route(async (req, res) => {
  const [row] = await q('SELECT * FROM listings_scored WHERE listing_id = $1', [req.params.id]);
  if (!row) return res.status(404).json({ status: 'pending' });
  res.json({ status: 'scored', listing: row });
}));

if (require.main === module) {
  app.listen(PORT, () => console.log(`API + web on http://localhost:${PORT}`));
}
module.exports = app;
