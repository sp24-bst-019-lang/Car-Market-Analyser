'use strict';
// Evaluates the model that Spark MLlib exported to ml_models.model_json.
// Mirrors spark/src/main/scala/pw/FeatureEngineering.scala (encode / addBasic) and ModelTraining.scala (nodeJson).

const lower = (s) => String(s || '').trim().replace(/\s+/g, ' ').toLowerCase();

/** One tree: leaf {v}, split {f, t, l, r}. MLlib sends a row left when feature <= threshold. */
function evalTree(node, x) {
  while (node.v === undefined) node = x[node.f] <= node.t ? node.l : node.r;
  return node.v;
}

/** Sum of weighted tree outputs = predicted ln(price). (Random forest weights are 1/n, GBT weights come from boosting.) */
function predictLog(model, x) {
  let s = 0;
  for (let i = 0; i < model.trees.length; i++) s += model.weights[i] * evalTree(model.trees[i], x);
  return s;
}

const FUEL = { petrol: 0, hybrid: 1, diesel: 2 };
const ASSEMBLY = { local: 0, imported: 1 };

/**
 * Build the model's input vector from a car and the statistics rows in enc_stats.
 * stats = { global: {n, sum_log_price}, make: row|null, family: row|null } (Number-compatible values).
 * Returns { x, used } where used says which statistics were available (drives the confidence level).
 */
function buildFeatures(model, input, stats) {
  const K = model.k;
  const G = Number(stats.global.sum_log_price) / Number(stats.global.n);
  const m = stats.make, f = stats.family;

  const encMake = ((m ? Number(m.sum_log_price) : 0) + K * G) / ((m ? Number(m.n) : 0) + K);
  const encFamily = ((f ? Number(f.sum_log_price) : 0) + K * encMake) / ((f ? Number(f.n) : 0) + K);

  const year = Number(input.year);
  const age = Math.max(model.ref_year - year, 1);
  const mileage = Number(input.mileage) > 0 ? Number(input.mileage)
    : (f && f.median_mileage ? Number(f.median_mileage) : (m && m.median_mileage ? Number(m.median_mileage) : 60000));
  const engine = Number(input.engine_cc) > 0 ? Number(input.engine_cc)
    : (f && f.median_engine_cc ? Number(f.median_engine_cc) : (m && m.median_engine_cc ? Number(m.median_engine_cc) : 1300));
  const tierRow = f || m;

  const values = {
    enc_family: encFamily,
    enc_make: encMake,
    model_year: year,
    ln_mileage: Math.log(Math.max(mileage, 1)),
    usage_intensity: mileage / age,
    engine_cc: engine,
    fuel_code: FUEL[lower(input.fuel)] ?? 3,
    assembly_code: ASSEMBLY[lower(input.assembly)] ?? 2,
    brand_tier: tierRow ? Number(tierRow.brand_tier) : 1,
  };
  const x = model.features.map((name) => values[name]);
  return { x, used: { family_n: f ? Number(f.n) : 0, make_n: m ? Number(m.n) : 0, mileage, engine } };
}

/** How much to trust the ML number, from how many listings of this model the statistics are based on. */
function mlConfidence(used) {
  if (used.family_n >= 30) return 'high';
  if (used.family_n >= 8) return 'medium';
  if (used.make_n >= 8) return 'low';
  return 'very_low';
}

/** Round a PKR amount to the nearest 5,000 for display. */
const roundPrice = (v) => Math.round(v / 5000) * 5000;

function predict(model, input, stats) {
  const { x, used } = buildFeatures(model, input, stats);
  const price = Math.exp(predictLog(model, x));
  return { price: roundPrice(price), confidence: mlConfidence(used), used };
}

/**
 * Decide which estimate to headline, using the holdout numbers Spark stored: the ML model only leads when its
 * median error on the same holdout is no worse than the comparable-listings baseline.
 */
function pickHeadline(metrics, mlAvailable, compsAvailable) {
  if (!mlAvailable) return 'comps';
  if (!compsAvailable) return 'ml';
  try {
    const chosen = metrics.holdout.candidates.find((c) => c.name === metrics.chosen);
    const base = metrics.holdout.baseline_comps;
    if (chosen && base && chosen.mdape != null && base.mdape != null) return chosen.mdape <= base.mdape ? 'ml' : 'comps';
  } catch (_) { /* fall through */ }
  return 'comps';
}

module.exports = { evalTree, predictLog, buildFeatures, mlConfidence, predict, pickHeadline };
