'use strict';
const test = require('node:test');
const assert = require('node:assert');
const M = require('../src/ml');

// A tiny model in the exact JSON shape ModelTraining.exportModel writes.
const model = {
  target: 'ln_price', ref_year: 2024, k: 5.0,
  features: ['enc_family', 'enc_make', 'model_year', 'ln_mileage', 'usage_intensity', 'engine_cc', 'fuel_code', 'assembly_code', 'brand_tier'],
  weights: [0.5, 0.5],
  trees: [
    { f: 2, t: 2015.5, l: { v: 14.0 }, r: { f: 0, t: 15.0, l: { v: 14.8 }, r: { v: 15.4 } } },
    { f: 8, t: 1.5, l: { v: 14.2 }, r: { v: 16.0 } },
  ],
};
const stats = {
  global: { n: 100, sum_log_price: 1400 },                               // overall mean 14
  make: { n: 10, sum_log_price: 150, median_mileage: 70000, median_engine_cc: 1800, brand_tier: 1 },
  family: { n: 5, sum_log_price: 80, median_mileage: 65000, median_engine_cc: 1600, brand_tier: 1 },
};

test('evalTree follows <= thresholds to the left', () => {
  const t = model.trees[0];
  assert.strictEqual(M.evalTree(t, [0, 0, 2015, 0]), 14.0);       // 2015 <= 2015.5 -> left
  assert.strictEqual(M.evalTree(t, [14.9, 0, 2016]), 14.8);       // right, then 14.9 <= 15 -> left
  assert.strictEqual(M.evalTree(t, [15.1, 0, 2016]), 15.4);
});

test('predictLog is the weighted sum of tree outputs', () => {
  const x = [14.9, 0, 2016, 0, 0, 0, 0, 0, 1];                     // tree0 -> 14.8, tree1 (tier 1 <= 1.5) -> 14.2
  assert.ok(Math.abs(M.predictLog(model, x) - (0.5 * 14.8 + 0.5 * 14.2)) < 1e-12);
});

test('encodings smooth toward the parent exactly like Spark encode()', () => {
  const { x } = M.buildFeatures(model, { make: 'Toyota', family: 'Corolla', year: 2018, mileage: 80000 }, stats);
  const encMake = (150 + 5 * 14) / (10 + 5);                       // 14.6667
  const encFamily = (80 + 5 * encMake) / (5 + 5);                  // 15.3333
  assert.ok(Math.abs(x[1] - encMake) < 1e-12);
  assert.ok(Math.abs(x[0] - encFamily) < 1e-12);
  assert.strictEqual(x[2], 2018);
  assert.ok(Math.abs(x[3] - Math.log(80000)) < 1e-12);
  assert.ok(Math.abs(x[4] - 80000 / 6) < 1e-9);                    // age = 2024 - 2018
});

test('unknown family falls back to the make, unknown make to the overall mean', () => {
  const a = M.buildFeatures(model, { year: 2018 }, { ...stats, family: null }).x;
  assert.ok(Math.abs(a[0] - a[1]) < 1e-12);
  const b = M.buildFeatures(model, { year: 2018 }, { global: stats.global, make: null, family: null }).x;
  assert.ok(Math.abs(b[0] - 14) < 1e-12 && Math.abs(b[1] - 14) < 1e-12);
});

test('missing mileage/engine use the model statistics; fuel/assembly codes match Spark', () => {
  const { x, used } = M.buildFeatures(model, { year: 2020, fuel: 'Hybrid', assembly: 'Imported' }, stats);
  assert.strictEqual(used.mileage, 65000);
  assert.strictEqual(x[5], 1600);
  assert.strictEqual(x[6], 1);
  assert.strictEqual(x[7], 1);
  const y = M.buildFeatures(model, { year: 2020 }, stats).x;
  assert.strictEqual(y[6], 3);
  assert.strictEqual(y[7], 2);
});

test('predict returns a rounded PKR price and a confidence level', () => {
  const p = M.predict(model, { make: 'Toyota', family: 'Corolla', year: 2018, mileage: 80000 }, stats);
  assert.strictEqual(p.price % 5000, 0);
  assert.ok(p.price > 1e6);
  assert.strictEqual(p.confidence, 'low');                         // family n=5 < 8, make n=10 >= 8
});

test('headline only goes to ML when it beats the baseline on the same holdout', () => {
  const metrics = (ml, base) => ({ chosen: 'gbt', holdout: { candidates: [{ name: 'gbt', mdape: ml }], baseline_comps: { mdape: base } } });
  assert.strictEqual(M.pickHeadline(metrics(0.06, 0.07), true, true), 'ml');
  assert.strictEqual(M.pickHeadline(metrics(0.09, 0.07), true, true), 'comps');
  assert.strictEqual(M.pickHeadline(metrics(0.06, 0.07), false, true), 'comps');
  assert.strictEqual(M.pickHeadline(metrics(0.06, 0.07), true, false), 'ml');
  assert.strictEqual(M.pickHeadline(null, true, true), 'comps');
});
