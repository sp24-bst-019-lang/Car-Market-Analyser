'use strict';
const test = require('node:test');
const assert = require('node:assert');
const P = require('../src/pricing');

test('cohort keys use the same format as Spark Comps.key', () => {
  const k = P.cohortKeys({ make: 'Toyota', family: 'Corolla', year: 2018, assembly: 'Local', fuel: 'Petrol' });
  assert.deepStrictEqual(k.map((x) => x.key), [
    '1|toyota|corolla|2018|Local|Petrol',
    '2|toyota|corolla|2018',
    '3|toyota|corolla|b2016',
    '4|toyota|corolla',
  ]);
});

test('missing assembly/fuel become * (Spark coalesce(..., "*"))', () => {
  const [l1] = P.cohortKeys({ make: 'Honda', family: 'Civic', year: 2005 });
  assert.strictEqual(l1.key, '1|honda|civic|2005|*|*');
});

test('3-year bands match floor(year/3)*3', () => {
  const band = (y) => P.cohortKeys({ make: 'a', family: 'b', year: y })[2].key.split('|')[3];
  assert.deepStrictEqual([2015, 2016, 2017, 2018].map(band), ['b2013', 'b2016', 'b2016', 'b2016']);
});

test('chooseComps prefers the most specific level with enough listings', () => {
  const rows = [
    { level: 4, n: 900, median_price: 3e6 }, { level: 1, n: 5, median_price: 4e6 },
    { level: 2, n: 20, median_price: 3.5e6 },
  ];
  assert.strictEqual(P.chooseComps(rows, 8).level, 2);   // level 1 has only 5 < 8
  assert.strictEqual(P.chooseComps(rows, 30).level, 4);
  assert.strictEqual(P.chooseComps([], 8), null);
});

test('deal labels follow the Spark thresholds', () => {
  const f = 1_000_000;
  assert.strictEqual(P.dealLabel(500_000, f), 'too_good_to_be_true');
  assert.strictEqual(P.dealLabel(800_000, f), 'great_deal');
  assert.strictEqual(P.dealLabel(900_000, f), 'good_deal');
  assert.strictEqual(P.dealLabel(1_100_000, f), 'fair');      // 1.10 is inclusive
  assert.strictEqual(P.dealLabel(1_200_000, f), 'high');
  assert.strictEqual(P.dealLabel(1_300_000, f), 'overpriced');
  assert.strictEqual(P.dealLabel(0, f), 'price_on_call');
  assert.strictEqual(P.dealLabel(1_000_000, null), 'unrated');
});

test('estimate returns band, confidence and ratio', () => {
  const e = P.estimate({ level: 1, n: 40, p25: 3.0e6, median_price: 3.4e6, p75: 3.8e6, median_mileage: 70000 }, 3_740_000);
  assert.strictEqual(e.confidence, 'high');
  assert.strictEqual(e.label, 'fair');
  assert.ok(Math.abs(e.ratio - 1.1) < 1e-9);
  assert.strictEqual(P.estimate(null, 1).available, false);
});

test('listingId is stable, ignores date/case/whitespace, and changes with price', () => {
  const a = P.listingId({ title: 'Honda  Civic EXi 2006', price: 1850000, city: 'Islamabad', mileage: 204000 });
  const b = P.listingId({ title: 'honda civic exi 2006', price: 1850000, city: ' islamabad ', mileage: 204000 });
  const c = P.listingId({ title: 'Honda Civic EXi 2006', price: 1800000, city: 'Islamabad', mileage: 204000 });
  assert.strictEqual(a, b);
  assert.notStrictEqual(a, c);
  assert.match(a, /^[0-9a-f]{64}$/);
});

test('validateListing rejects bad input and builds a Spark-shaped event', () => {
  assert.strictEqual(P.validateListing({}).ok, false);
  assert.strictEqual(P.validateListing({ make: 'Toyota', family: 'Corolla', year: 1800, mileage: 1, city: 'Lahore' }).ok, false);
  const v = P.validateListing({ make: 'Toyota', family: 'Corolla', variant: 'Altis 1.6', year: 2018, mileage: 80000, price: 4200000, city: 'Lahore', fuel: 'Petrol' });
  assert.ok(v.ok);
  const ev = P.toEvent(v.value);
  assert.strictEqual(ev.title, 'Toyota Corolla Altis 1.6 2018');
  assert.strictEqual(ev.model, 2018);
  assert.match(ev.post_date, /^\d{4}-\d{2}-\d{2}$/);
});
