package pw

import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.{Column, DataFrame}

/**
 * Cleaning shared by the batch job (CSV) and the streaming job (JSON events).
 *
 * Deliberately dropped from the source file:
 *  - transmission: 40% "Not Available" and exactly one "Manual" row, so it is unusable.
 *  - price_category / mileage_category: tertile buckets derived from price/mileage, they add no information.
 *  - post_day_of_week / vehicle_age: derived from post_date / model.
 *  - color: 809 free-text variants and no pricing signal worth the noise.
 */
object Clean {

  /** Full schema of the PakWheels CSV (read by position). */
  val csvSchema: StructType = StructType(Seq(
    StructField("title", StringType), StructField("price", LongType), StructField("city", StringType),
    StructField("model", IntegerType), StructField("mileage", LongType), StructField("fuel_type", StringType),
    StructField("transmission", StringType), StructField("registered", StringType), StructField("color", StringType),
    StructField("assembly", StringType), StructField("engine_capacity", IntegerType), StructField("post_date", StringType),
    StructField("price_category", StringType), StructField("mileage_category", StringType),
    StructField("post_day_of_week", StringType), StructField("vehicle_age", IntegerType)
  ))

  /** Schema of a new-listing event posted by the API. */
  val eventSchema: StructType = StructType(Seq(
    StructField("title", StringType), StructField("price", LongType), StructField("city", StringType),
    StructField("model", IntegerType), StructField("mileage", LongType), StructField("fuel_type", StringType),
    StructField("assembly", StringType), StructField("engine_capacity", IntegerType), StructField("post_date", StringType)
  ))

  // Makes whose names are two words ("Mercedes Benz S Class 2022").
  private val TwoWordMake =
    """^(Mercedes Benz|Land Rover|Range Rover|Master Foton|Alfa Romeo|Rolls Royce|Aston Martin|Great Wall)\b"""
  // Families whose names are two words ("Toyota Land Cruiser ...").
  private val TwoWordFamily =
    """^(Land Cruiser|Yaris Cross|Corolla Cross|[A-Z] Class|N (?:One|Box|Wgn)|Grand Vitara|Wagon R)\b"""
  private val FirstToken = """^(\S+)"""

  private def nullIfNA(c: Column): Column =
    when(c.isNull || trim(c) === "" || trim(c) === "Not Available", lit(null).cast(StringType)).otherwise(trim(c))

  /** Normalise raw rows/events into the canonical listing shape. Requires title, price, city, model, mileage, fuel_type, assembly, engine_capacity, post_date. */
  def normalize(raw: DataFrame): DataFrame = {
    val withTitle = raw.withColumn("title", trim(regexp_replace(col("title"), "\\s+", " ")))

    val twoMake = regexp_extract(col("title"), TwoWordMake, 1)
    val withMake = withTitle.withColumn("make",
      when(length(twoMake) > 0, twoMake).otherwise(regexp_extract(col("title"), FirstToken, 1)))

    val withRest = withMake.withColumn("rest", trim(col("title").substr(length(col("make")) + 1, lit(1000))))

    val twoFam = regexp_extract(col("rest"), TwoWordFamily, 1)
    val withFamily = withRest.withColumn("family",
      when(length(twoFam) > 0, twoFam).otherwise(regexp_extract(col("rest"), FirstToken, 1)))

    withFamily
      .withColumn("model_year", col("model").cast(IntegerType))
      .withColumn("price", when(col("price") > 0, col("price").cast(LongType))) // 0 means "call for price" -> NULL
      .withColumn("city", initcap(trim(col("city"))))
      .withColumn("mileage", col("mileage").cast(LongType))
      .withColumn("fuel", nullIfNA(col("fuel_type")))
      .withColumn("assembly", nullIfNA(col("assembly")))
      .withColumn("engine_cc", col("engine_capacity").cast(IntegerType))
      .withColumn("post_date", coalesce(to_date(col("post_date")), current_date()))
      .withColumn("age", year(col("post_date")) - col("model_year"))
      // Fingerprint ignores post_date so a re-post of the same car on another day collides.
      // The API computes the identical hash (api/src/pricing.js: listingId).
      .withColumn("listing_id", sha2(concat_ws("|",
        lower(col("title")),
        coalesce(col("price").cast(StringType), lit("0")),
        lower(col("city")),
        col("mileage").cast(StringType)), 256))
      .filter(col("title").isNotNull && col("model_year").isNotNull && col("make") =!= "")
      .select("listing_id", "title", "make", "family", "model_year", "city", "price", "mileage",
        "fuel", "assembly", "engine_cc", "post_date", "age")
  }

  /** Collapse duplicates of the same fingerprint into one row (latest post_date) and count the extra copies. */
  def dedupe(df: DataFrame): DataFrame = {
    val byOrder = Window.partitionBy("listing_id").orderBy(col("post_date").desc)
    val byId = Window.partitionBy("listing_id")
    df.withColumn("rn", row_number().over(byOrder))
      .withColumn("repost_count", (count(lit(1)).over(byId) - 1).cast(IntegerType))
      .filter(col("rn") === 1)
      .drop("rn")
  }
}
