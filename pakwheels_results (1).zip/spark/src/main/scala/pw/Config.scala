package pw

/** All runtime settings come from environment variables so the same jar runs locally and in the cloud. */
object Config {
  private def env(k: String, d: String): String = sys.env.getOrElse(k, d)

  /** "jdbc" writes to cloud Postgres; "parquet" writes local files (handy for dev without a database). */
  val sink: String = env("SINK", "jdbc")

  // Cloud Postgres (Neon / Supabase / RDS / Cloud SQL), e.g. jdbc:postgresql://HOST/DB?sslmode=require&reWriteBatchedInserts=true
  val jdbcUrl: String = env("JDBC_URL", "")
  val dbUser: String = env("DB_USER", "")
  val dbPassword: String = env("DB_PASSWORD", "")

  val outDir: String = env("OUT_DIR", "out")
  val inputCsv: String = env("INPUT_CSV", "data/raw/pakwheels_pakistan_automobile_dataset.csv")

  /** Directory (or s3a:// / gs:// path) the API drops new-listing JSON files into. */
  val incomingPath: String = env("INCOMING_PATH", "incoming")
  val checkpointPath: String = env("CHECKPOINT_PATH", "checkpoint")

  /** Minimum listings a comparable group needs before it is used for pricing. */
  val minComps: Int = env("MIN_COMPS", "8").toInt
}
