package pw

import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame}

/**
 * Scores listings against the comps table: fair price, deal label and listing-quality flags.
 * Used by BOTH the batch job (backfill) and the streaming job (new listings), so results are consistent.
 *
 * IMPORTANT: the flags are review heuristics, not fraud labels. The dataset has no ground truth.
 * Thresholds were checked on the provided data (flag rates: too-low 1.7%, too-high 1.2%, mileage placeholder 1.3%).
 */
object Scoring {

  /** Columns persisted to listings_scored (the batch job adds repost_count). */
  val outCols: Seq[String] = Seq(
    "listing_id", "title", "make", "family", "model_year", "city", "price", "mileage", "fuel", "assembly",
    "engine_cc", "post_date", "fair_price", "fair_low", "fair_high", "deal_ratio", "deal_label",
    "comp_level", "comp_n", "confidence", "flags", "risk_score", "risk_level")

  // (flag name, weight 0-100, condition). Weights add up and are capped at 100.
  private def rules(ratio: Column): Seq[(String, Int, Column)] = Seq(
    ("PRICE_ON_CALL",       5,  col("price").isNull),
    ("PRICE_TOO_LOW",       50, ratio < 0.55),               // bait pricing / scam signal
    ("PRICE_TOO_HIGH",      20, ratio > 1.6),
    ("MILEAGE_PLACEHOLDER", 30, col("mileage") <= 100 && col("age") > 3), // e.g. "1 km" on a 6-year-old car
    ("MILEAGE_EXTREME",     15, col("mileage") >= 500000 || (col("age") >= 2 && col("mileage") / col("age") > 60000)),
    ("NO_COMPARABLES",      5,  col("comp_level").isNull)
  )

  def score(clean: DataFrame, comps: DataFrame, minN: Int): DataFrame = {
    def level(l: Int): DataFrame =
      comps.filter(col("level") === l && col("n") >= minN)
        .select(
          col("cohort_key").as(s"k$l"), col("n").as(s"n_$l"), col("p25").as(s"p25_$l"),
          col("median_price").as(s"med_$l"), col("p75").as(s"p75_$l"))

    // Join each of the four levels; a null means that level has too few listings.
    val joined = (1 to 4).foldLeft(clean) { (d, l) =>
      d.withColumn(s"k$l", Comps.key(l)).join(broadcast(level(l)), Seq(s"k$l"), "left")
    }

    def pick(c: String): Column = coalesce((1 to 4).map(l => col(s"${c}_$l")): _*)

    val withFair = joined
      .withColumn("comp_level", coalesce((1 to 4).map(l => when(col(s"n_$l").isNotNull, lit(l))): _*))
      .withColumn("comp_n", pick("n"))
      .withColumn("fair_price", pick("med").cast("long"))
      .withColumn("fair_low", pick("p25").cast("long"))
      .withColumn("fair_high", pick("p75").cast("long"))
      .withColumn("deal_ratio", col("price") / col("fair_price"))

    val ratio = col("deal_ratio")
    val labelled = withFair
      .withColumn("deal_label",
        when(col("price").isNull, "price_on_call")
          .when(col("fair_price").isNull, "unrated")
          .when(ratio < 0.55, "too_good_to_be_true")
          .when(ratio < 0.85, "great_deal")
          .when(ratio < 0.95, "good_deal")
          .when(ratio <= 1.10, "fair")
          .when(ratio <= 1.25, "high")
          .otherwise("overpriced"))
      .withColumn("confidence",
        when(col("comp_level") === 1, "high")
          .when(col("comp_level").isin(2, 3), "medium")
          .when(col("comp_level") === 4, "low")
          .otherwise("none"))

    val rs = rules(ratio)
    val flags = concat_ws(",", rs.map { case (name, _, cond) => when(cond, lit(name)) }: _*)
    val risk = least(lit(100), rs.map { case (_, w, cond) => coalesce(when(cond, lit(w)), lit(0)) }.reduce(_ + _))

    labelled
      .withColumn("flags", flags)
      .withColumn("risk_score", risk.cast("int"))
      .withColumn("risk_level",
        when(col("risk_score") >= 50, "high").when(col("risk_score") >= 20, "medium")
          .when(col("risk_score") > 0, "low").otherwise("none"))
  }
}
