package pw

import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

/** Step 1 (proposal: 01_data_ingestion). Load the raw CSV and run schema and consistency checks. */
object Ingestion {

  def load(spark: SparkSession): DataFrame =
    spark.read.option("header", "true").schema(Clean.csvSchema).csv(Config.inputCsv)

  /** One row per check: (check_name, n, detail). Saved to the data_quality table and shown in the app. */
  def qualityReport(spark: SparkSession, raw: DataFrame): DataFrame = {
    import spark.implicits._
    val age = year(to_date(col("post_date"))) - col("model")
    def cnt(cond: org.apache.spark.sql.Column) = sum(when(cond, 1).otherwise(0))

    val r = raw.agg(
      count(lit(1)).as("total"),
      cnt(col("price") === 0).as("price_zero"),
      cnt(col("fuel_type") === "Not Available").as("fuel_unknown"),
      cnt(col("transmission") === "Not Available").as("transmission_unknown"),
      cnt(col("assembly") === "Not Available").as("assembly_unknown"),
      cnt(col("mileage") <= 100 && age > 3).as("mileage_placeholder"),
      cnt(col("mileage") >= 500000).as("mileage_extreme"),
      cnt(col("title").isNull || col("city").isNull || col("model").isNull).as("missing_key_fields"),
      countDistinct("city").as("distinct_cities")
    ).head()

    val total = r.getAs[Long]("total")
    val distinctRows = raw.distinct().count()
    val schemaText = raw.schema.fields.map(f => s"${f.name}:${f.dataType.simpleString}").mkString(", ")

    Seq(
      ("total_rows", total, "rows in the raw CSV"),
      ("exact_duplicate_rows", total - distinctRows, "identical rows, removed in preprocessing"),
      ("price_zero", r.getAs[Long]("price_zero"), "price = 0 means call for price; treated as missing"),
      ("mileage_placeholder", r.getAs[Long]("mileage_placeholder"), "mileage <= 100 km on a car older than 3 years"),
      ("mileage_extreme", r.getAs[Long]("mileage_extreme"), "mileage >= 500,000 km"),
      ("fuel_unknown", r.getAs[Long]("fuel_unknown"), "fuel type Not Available"),
      ("assembly_unknown", r.getAs[Long]("assembly_unknown"), "assembly Not Available"),
      ("transmission_unknown", r.getAs[Long]("transmission_unknown"), "transmission Not Available; column dropped (unusable)"),
      ("missing_key_fields", r.getAs[Long]("missing_key_fields"), "missing title, city or model year"),
      ("distinct_cities", r.getAs[Long]("distinct_cities"), "free-text city names before cleaning"),
      ("schema", 0L, schemaText)
    ).toDF("check_name", "n", "detail")
  }
}
