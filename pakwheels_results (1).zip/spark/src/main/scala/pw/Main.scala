package pw

import scala.collection.mutable.ArrayBuffer

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col

/**
 * AutoVal-Intel pipeline orchestrator (proposal: main.py). Runs every stage in order and logs timings:
 *
 *   1 Ingestion          load CSV + data-quality report
 *   2 Preprocessing      clean, de-duplicate, remove outliers
 *   3 CloudLoader        push cleaned data to the cloud database
 *   4 Scoring            comparable-listing prices, deal labels, risk flags, city index, map coordinates
 *   5 ModelTraining      MLlib regression + classification, export for the API
 *   6 MarketInsights     depreciation, resale windows, market segments, brand summary
 *
 * Run: spark-submit --class pw.Main pakwheels-spark.jar   (see scripts/01_pipeline.sh)
 */
object Main {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("autoval-intel-pipeline").getOrCreate()
    spark.sparkContext.setLogLevel("WARN")
    import spark.implicits._

    val runLog = ArrayBuffer.empty[(Int, String, Long, Double)]
    def stage[T](step: Int, name: String)(body: => (T, Long)): T = {
      println(s"\n=== [$step] $name ===")
      val t0 = System.nanoTime()
      val (result, rows) = body
      val secs = (System.nanoTime() - t0) / 1e9
      runLog += ((step, name, rows, secs))
      println(f"=== [$step] $name done in $secs%.1fs ($rows rows) ===")
      result
    }

    // 1 -------------------------------------------------------------------------------------------
    val raw = stage(1, "Ingestion") {
      val df = Ingestion.load(spark).cache()
      val report = Ingestion.qualityReport(spark, df)
      report.show(20, truncate = false)
      CloudLoader.push(report, "data_quality")
      (df, df.count())
    }

    // 2 -------------------------------------------------------------------------------------------
    val prep = stage(2, "Preprocessing") {
      val r = Preprocessing.run(raw)
      println(s"  clean listings: ${r.clean.count()}, ML training rows: ${r.training.count()}")
      (r, r.clean.count())
    }

    // 3 -------------------------------------------------------------------------------------------
    stage(3, "CloudLoader") {
      CloudLoader.pushClean(prep.clean)
      ((), prep.clean.count())
    }

    // 4 -------------------------------------------------------------------------------------------
    stage(4, "Scoring") {
      val comps = Comps.build(prep.clean).cache()
      val scored = Scoring.score(prep.clean, comps, Config.minComps).cache()
      scored.groupBy("risk_level").count().show()
      CloudLoader.push(comps, "comps")
      CloudLoader.push(CityIndex.build(scored), "city_index")
      CloudLoader.push(Geo.table(spark), "city_geo")
      CloudLoader.push(scored.select((Scoring.outCols :+ "repost_count").map(col): _*), "listings_scored")
      ((), scored.count())
    }

    // 5 -------------------------------------------------------------------------------------------
    stage(5, "ModelTraining") {
      ModelTraining.run(spark, prep.training)
      ((), prep.training.count())
    }

    // 6 -------------------------------------------------------------------------------------------
    stage(6, "MarketInsights") {
      val depFamily = MarketInsights.depreciation(prep.training, Seq("make", "family")).cache()
      val depMake = MarketInsights.depreciation(prep.training, Seq("make")).cache()
      val dep = depFamily.unionByName(depMake)
      CloudLoader.push(
        dep.select("make", "family", "age", "n", "p25", "median_price", "p75", "dep_rate", "retained_pct"),
        "depreciation")
      CloudLoader.push(MarketInsights.resaleWindows(dep), "resale_windows")
      CloudLoader.push(MarketInsights.segments(prep.clean), "market_segments")
      CloudLoader.push(MarketInsights.brands(prep.clean, depMake), "brand_summary")
      ((), dep.count())
    }

    CloudLoader.pushRunLog(spark, runLog.toSeq)
    println("\nPipeline finished.")
    spark.stop()
  }
}
