package pw

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

/**
 * Step 2 (proposal: 02_data_preprocessing). Null handling, de-duplication, outlier removal and encoding.
 *
 * Two outputs:
 *  - clean:    every listing, normalised (used by the app, scoring and market insights).
 *  - training: priced listings with unrealistic mileage and price outliers removed (used to train ML models).
 * The two are kept apart so that suspicious listings stay visible to the screening tab but cannot distort the models.
 */
object Preprocessing {

  case class Result(clean: DataFrame, training: DataFrame)

  def run(raw: DataFrame): Result = {
    val clean = Clean.dedupe(Clean.normalize(raw)).cache()

    // Hard sanity limits first.
    val sane = clean.filter(
      col("price").isNotNull &&
        col("price").between(100000L, 400000000L) &&
        col("mileage") > 0 && col("mileage") < 500000 &&
        !(col("mileage") <= 100 && col("age") > 3) &&
        col("age") >= 0)

    // Then drop listings priced far away from their peers (typos such as an extra zero).
    val c = Comps.build(sane).filter(col("n") >= 8)
    val l2 = c.filter(col("level") === 2).select(col("cohort_key").as("k2"), col("median_price").as("med2"))
    val l4 = c.filter(col("level") === 4).select(col("cohort_key").as("k4"), col("median_price").as("med4"))

    val training = sane
      .withColumn("k2", Comps.key(2)).withColumn("k4", Comps.key(4))
      .join(broadcast(l2), Seq("k2"), "left")
      .join(broadcast(l4), Seq("k4"), "left")
      .withColumn("peer_med", coalesce(col("med2"), col("med4")))
      .filter(col("peer_med").isNull ||
        (col("price") >= col("peer_med") * 0.33 && col("price") <= col("peer_med") * 3.0))
      .drop("k2", "k4", "med2", "med4", "peer_med")
      .cache()

    Result(clean, training)
  }
}
