package pw

import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame}

/**
 * "Comparable groups": for each listing, four nested groups of similar cars, from specific to broad.
 *
 *   level 1: make | family | model_year | assembly | fuel
 *   level 2: make | family | model_year
 *   level 3: make | family | 3-year model-year band
 *   level 4: make | family
 *
 * A listing is priced from the most specific group that has at least MIN_COMPS listings.
 * Holdout test (5-fold on the provided data): median error ~6.5% at level 1, ~11% at levels 2-3, ~29% at level 4.
 * Mileage was tested as an extra adjustment and did NOT improve error on this data, so it is not used.
 *
 * The key format is mirrored in api/src/pricing.js (cohortKeys). Change both together.
 */
object Comps {

  def key(level: Int): Column = {
    val base = concat_ws("|", lit(level.toString), lower(col("make")), lower(col("family")))
    level match {
      case 1 => concat_ws("|", base, col("model_year").cast("string"),
                  coalesce(col("assembly"), lit("*")), coalesce(col("fuel"), lit("*")))
      case 2 => concat_ws("|", base, col("model_year").cast("string"))
      case 3 => concat_ws("|", base, concat(lit("b"), (floor(col("model_year") / 3) * 3).cast("int").cast("string")))
      case 4 => base
      case _ => throw new IllegalArgumentException(s"bad level $level")
    }
  }

  /** Store groups with at least this many listings; the scorer applies its own (higher) MIN_COMPS. */
  private val MinStore = 5

  def build(clean: DataFrame): DataFrame = {
    val priced = clean.filter(col("price").isNotNull)

    val perLevel = (1 to 4).map { l =>
      val aggs = Seq(
        max("make").as("make"),
        max("family").as("family"),
        count(lit(1)).as("n"),
        expr("percentile_approx(price, 0.25, 1000)").cast("long").as("p25"),
        expr("percentile_approx(price, 0.5, 1000)").cast("long").as("median_price"),
        expr("percentile_approx(price, 0.75, 1000)").cast("long").as("p75"),
        expr("percentile_approx(mileage, 0.5, 1000)").cast("long").as("median_mileage")
      ) ++ (if (l <= 2) Seq(max("model_year").as("model_year")) else Nil)

      val grouped = priced.withColumn("cohort_key", key(l)).groupBy("cohort_key").agg(aggs.head, aggs.tail: _*)
      val withYear = if (l <= 2) grouped else grouped.withColumn("model_year", lit(null).cast("int"))

      withYear
        .filter(col("n") >= MinStore)
        .withColumn("level", lit(l))
        .select("cohort_key", "level", "make", "family", "model_year", "n", "p25", "median_price", "p75", "median_mileage")
    }
    perLevel.reduce(_ unionByName _)
  }
}
