package pw

import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame}

/**
 * Step 4 (proposal: 04_feature_engineering).
 *
 * Features (all numeric, so tree models export cleanly to JSON for the API):
 *  - model_year, ln_mileage
 *  - usage_intensity = mileage / max(age, 1)               (proposal feature)
 *  - brand_tier: 0 Economy, 1 Mainstream, 2 Premium, 3 Luxury, from the make's median price (proposal feature)
 *  - engine_cc, fuel_code, assembly_code
 *  - enc_make, enc_family: smoothed mean of ln(price) for the make and for the make+model.
 *    Models have 400+ families, too many for a tree to split on directly, so each family is described by
 *    how expensive it typically is. Small groups are pulled towards their parent (family -> make -> overall)
 *    with strength K, and for training rows the row's own price is left out (leave-one-out) so the model
 *    cannot read its own answer.
 *
 * The same arithmetic is repeated in api/src/ml.js (buildFeatures). Change both together.
 */
object FeatureEngineering {

  /** Smoothing strength: a group counts as K extra listings of its parent's average. Mirrored in the API. */
  val K = 5.0

  /** Order of the model's input vector. The exported JSON lists these names so the API can't mix them up. */
  val Features: Seq[String] = Seq("enc_family", "enc_make", "model_year", "ln_mileage", "usage_intensity",
    "engine_cc", "fuel_code", "assembly_code", "brand_tier")

  /** Brand tier from a make's median price (PKR). */
  def tier(medianPrice: Column): Column =
    when(medianPrice < 1600000, 0).when(medianPrice < 4000000, 1).when(medianPrice < 10000000, 2).otherwise(3)

  /** Row-level features that need no statistics. Requires: mileage, age, engine_cc, fuel, assembly. */
  def addBasic(df: DataFrame): DataFrame =
    df.withColumn("usage_intensity", col("mileage") / greatest(col("age"), lit(1)))
      .withColumn("ln_mileage", log(greatest(col("mileage"), lit(1L)).cast("double")))
      .withColumn("engine_cc", coalesce(col("engine_cc"), lit(1300)))
      .withColumn("fuel_code",
        when(col("fuel") === "Petrol", 0).when(col("fuel") === "Hybrid", 1).when(col("fuel") === "Diesel", 2).otherwise(3))
      .withColumn("assembly_code",
        when(col("assembly") === "Local", 0).when(col("assembly") === "Imported", 1).otherwise(2))

  /**
   * Per-group statistics from priced rows. One row per group:
   * kind = global | make | family, make/family lower-case ('*' where not applicable).
   * Saved as enc_stats and read by the API to build features for a car the models have never seen.
   */
  def buildStats(df: DataFrame): DataFrame = {
    val d = df
      .withColumn("ln_price", log(col("price").cast("double")))
      .withColumn("mk", lower(col("make")))
      .withColumn("fm", lower(col("family")))

    def aggs: Seq[Column] = Seq(
      count(lit(1)).as("n"),
      sum("ln_price").as("sum_log_price"),
      expr("percentile_approx(engine_cc, 0.5, 100)").cast("long").as("median_engine_cc"),
      expr("percentile_approx(mileage, 0.5, 1000)").cast("long").as("median_mileage"),
      expr("percentile_approx(price, 0.5, 1000)").cast("long").as("median_price"))

    val make = d.groupBy("mk").agg(aggs.head, aggs.tail: _*)
      .select(lit("make").as("kind"), col("mk").as("make"), lit("*").as("family"), col("n"), col("sum_log_price"),
        col("median_engine_cc"), col("median_mileage"), tier(col("median_price")).as("brand_tier"))

    val tiers = make.select(col("make").as("tmk"), col("brand_tier").as("tier_make"))

    val family = d.groupBy("mk", "fm").agg(aggs.head, aggs.tail: _*)
      .join(tiers, col("mk") === col("tmk"))
      .select(lit("family").as("kind"), col("mk").as("make"), col("fm").as("family"), col("n"), col("sum_log_price"),
        col("median_engine_cc"), col("median_mileage"), col("tier_make").as("brand_tier"))

    val global = d.agg(aggs.head, aggs.tail: _*)
      .select(lit("global").as("kind"), lit("*").as("make"), lit("*").as("family"), col("n"), col("sum_log_price"),
        col("median_engine_cc"), col("median_mileage"), lit(1).as("brand_tier"))

    make.unionByName(family).unionByName(global)
  }

  /**
   * Adds enc_make, enc_family and brand_tier. loo = true for training rows (leave the row's own price out).
   * Requires: make, family and, when loo = true, price.
   */
  def encode(df: DataFrame, stats: DataFrame, loo: Boolean): DataFrame = {
    val g = stats.filter(col("kind") === "global").select("n", "sum_log_price").head()
    val prior = g.getAs[Double]("sum_log_price") / g.getAs[Long]("n")

    val ms = stats.filter(col("kind") === "make").select(
      col("make").as("s_mk"), col("n").as("n_m"), col("sum_log_price").as("sum_m"), col("brand_tier").as("tier_m"))
    val fs = stats.filter(col("kind") === "family").select(
      col("make").as("s_mk2"), col("family").as("s_fm"), col("n").as("n_f"),
      col("sum_log_price").as("sum_f"), col("brand_tier").as("tier_f"))

    val k = lit(K)
    val own: Column = if (loo) log(col("price").cast("double")) else lit(0.0)
    val cnt: Column = if (loo) lit(1L) else lit(0L)

    df.withColumn("mk", lower(col("make"))).withColumn("fm", lower(col("family")))
      .join(broadcast(ms), col("mk") === col("s_mk"), "left")
      .join(broadcast(fs), col("mk") === col("s_mk2") && col("fm") === col("s_fm"), "left")
      .withColumn("enc_make",
        (coalesce(col("sum_m") - own, lit(0.0)) + k * lit(prior)) / (coalesce(col("n_m") - cnt, lit(0L)) + k))
      .withColumn("enc_family",
        (coalesce(col("sum_f") - own, lit(0.0)) + k * col("enc_make")) / (coalesce(col("n_f") - cnt, lit(0L)) + k))
      .withColumn("brand_tier", coalesce(col("tier_f"), col("tier_m"), lit(1)))
      .drop("mk", "fm", "s_mk", "s_mk2", "s_fm", "n_m", "sum_m", "tier_m", "n_f", "sum_f", "tier_f")
  }
}
