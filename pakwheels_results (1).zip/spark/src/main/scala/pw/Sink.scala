package pw

import java.sql.DriverManager

import org.apache.spark.sql.functions.col
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

/** Where results go: cloud Postgres via JDBC (default) or local Parquet files (SINK=parquet, for development). */
object Sink {

  private def jdbcReader(spark: SparkSession, table: String) =
    spark.read.format("jdbc")
      .option("url", Config.jdbcUrl).option("dbtable", table)
      .option("user", Config.dbUser).option("password", Config.dbPassword)
      .option("driver", "org.postgresql.Driver")

  /** Replace the contents of a table. JDBC uses TRUNCATE so the schema and indexes from sql/schema.sql survive. */
  def overwrite(df: DataFrame, table: String): Unit =
    if (Config.sink == "parquet") {
      df.write.mode(SaveMode.Overwrite).parquet(s"${Config.outDir}/$table")
    } else {
      df.coalesce(4).write.format("jdbc")
        .option("url", Config.jdbcUrl).option("dbtable", table)
        .option("user", Config.dbUser).option("password", Config.dbPassword)
        .option("driver", "org.postgresql.Driver")
        .option("truncate", "true").option("batchsize", "5000")
        .mode(SaveMode.Overwrite).save()
    }

  def read(spark: SparkSession, table: String): DataFrame =
    if (Config.sink == "parquet") spark.read.parquet(s"${Config.outDir}/$table")
    else jdbcReader(spark, table).load()

  /**
   * Idempotent upsert of scored streaming rows into listings_scored.
   * A repeated fingerprint (same car re-posted) increments repost_count. Delivery is at-least-once,
   * so a replayed micro-batch after a crash can over-count reposts by one.
   */
  def upsertScored(scored: DataFrame): Unit = {
    val out = scored.select(Scoring.outCols.map(col): _*)
    if (Config.sink == "parquet") {
      out.write.mode(SaveMode.Append).parquet(s"${Config.outDir}/listings_scored_stream")
    } else {
      out.write.format("jdbc")
        .option("url", Config.jdbcUrl).option("dbtable", "stg_listings_scored")
        .option("user", Config.dbUser).option("password", Config.dbPassword)
        .option("driver", "org.postgresql.Driver")
        .option("truncate", "true")
        .mode(SaveMode.Overwrite).save()

      val cols = Scoring.outCols.mkString(", ")
      val updates = (Scoring.outCols.filterNot(_ == "listing_id").map(c => s"$c = EXCLUDED.$c") ++
        Seq("repost_count = listings_scored.repost_count + 1", "source = 'stream'", "scored_at = now()")).mkString(", ")
      val sql =
        s"""INSERT INTO listings_scored ($cols, source)
           |SELECT $cols, 'stream' FROM stg_listings_scored
           |ON CONFLICT (listing_id) DO UPDATE SET $updates""".stripMargin

      Class.forName("org.postgresql.Driver")
      val conn = DriverManager.getConnection(Config.jdbcUrl, Config.dbUser, Config.dbPassword)
      try conn.createStatement().execute(sql) finally conn.close()
    }
  }
}
