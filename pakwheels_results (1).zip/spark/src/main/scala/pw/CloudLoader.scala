package pw

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.col

/** Step 3 (proposal: 03_cloud_loader). Push datasets from Spark to the cloud database. */
object CloudLoader {

  private val cleanCols = Seq("listing_id", "title", "make", "family", "model_year", "city", "price", "mileage",
    "fuel", "assembly", "engine_cc", "post_date", "age", "repost_count")

  /** The cleaned vehicle dataset itself. */
  def pushClean(clean: DataFrame): Unit =
    Sink.overwrite(clean.select(cleanCols.map(col): _*), "listings_clean")

  /** Any other result table (scores, insights, model artefacts). */
  def push(df: DataFrame, table: String): Unit = Sink.overwrite(df, table)

  def pushRunLog(spark: SparkSession, log: Seq[(Int, String, Long, Double)]): Unit = {
    import spark.implicits._
    Sink.overwrite(log.toDF("step", "stage", "row_count", "seconds"), "pipeline_runs")
  }
}
