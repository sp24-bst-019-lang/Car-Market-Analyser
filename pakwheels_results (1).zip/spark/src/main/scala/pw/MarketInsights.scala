package pw

import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame}

/**
 * Step 6 (proposal: 06_market_insights).
 *
 *  - depreciation:    median price by car age per model (and per make, family = '*'), yearly value loss, value retained.
 *  - resale_windows:  the 3-year age window where a model loses the least value per year, and where it drops fastest.
 *  - market_segments: listing volume per model. A proxy for how active a segment is, NOT sales or demand
 *                     (the data has no sold/expired status).
 *  - brand_summary:   per make: tier, volume, typical price/age and average yearly depreciation.
 *
 * All depreciation numbers come from a cross-section of cars of different ages listed at the same time,
 * not from tracking the same cars over time.
 */
object MarketInsights {

  private def pct(c: String, p: Double): Column = expr(s"percentile_approx($c, $p, 1000)").cast("long")

  /** keys = Seq("make", "family") or Seq("make"). Groups with fewer than 8 listings per age are dropped. */
  def depreciation(training: DataFrame, keys: Seq[String]): DataFrame = {
    val grouped = training
      .filter(col("age").between(0, 30))
      .groupBy((keys :+ "age").map(col): _*)
      .agg(
        count(lit(1)).as("n"),
        pct("price", 0.25).as("p25"),
        pct("price", 0.5).as("median_price"),
        pct("price", 0.75).as("p75"))
      .filter(col("n") >= 8)

    val w = Window.partitionBy(keys.map(col): _*).orderBy("age")
    val out = grouped
      .withColumn("prev_age", lag("age", 1).over(w))
      .withColumn("prev_price", lag("median_price", 1).over(w))
      // Only compare consecutive ages, otherwise the drop would span several years.
      .withColumn("dep_rate", when(col("age") - col("prev_age") === 1, lit(1.0) - col("median_price") / col("prev_price")))
      .withColumn("retained_pct", col("median_price") / first("median_price").over(w) * 100.0)
      .drop("prev_age", "prev_price")

    if (keys.contains("family")) out else out.withColumn("family", lit("*"))
  }

  /** Ages grouped as windows of three consecutive years; pick the window with the lowest average yearly loss. */
  def resaleWindows(dep: DataFrame): DataFrame = {
    val keys = Seq("make", "family")
    val part = keys.map(col)
    val w3 = Window.partitionBy(part: _*).orderBy("age").rowsBetween(0, 2)

    val windows = dep.filter(col("dep_rate").isNotNull)
      .withColumn("win_avg", avg(col("dep_rate")).over(w3))
      .withColumn("win_cnt", count(col("dep_rate")).over(w3))
      .withColumn("win_end", max(col("age")).over(w3))
      .filter(col("win_cnt") === 3 && col("win_end") - col("age") === 2)

    val best = windows
      .withColumn("rn", row_number().over(Window.partitionBy(part: _*).orderBy(col("win_avg").asc)))
      .filter(col("rn") === 1)
      .select(col("make"), col("family"), col("age").as("window_start_age"),
        (col("age") + 2).as("window_end_age"), col("win_avg").as("window_avg_dep_rate"))

    val steepest = dep.filter(col("dep_rate").isNotNull)
      .withColumn("rn", row_number().over(Window.partitionBy(part: _*).orderBy(col("dep_rate").desc)))
      .filter(col("rn") === 1)
      .select(col("make"), col("family"), col("age").as("steepest_age"), col("dep_rate").as("steepest_rate"))

    val volume = dep.groupBy("make", "family").agg(sum("n").as("n"))

    best.join(steepest, keys).join(volume, keys)
      .select("make", "family", "n", "window_start_age", "window_end_age", "window_avg_dep_rate",
        "steepest_age", "steepest_rate")
  }

  /** Listing volume per model with an activity level by rank among all models. */
  def segments(clean: DataFrame): DataFrame = {
    val total = clean.count().toDouble
    clean.groupBy("make", "family")
      .agg(count(lit(1)).as("n"), pct("price", 0.25).as("p25"), pct("price", 0.5).as("median_price"), pct("price", 0.75).as("p75"))
      .filter(col("n") >= 20 && col("median_price").isNotNull)
      .withColumn("spread_ratio", (col("p75") - col("p25")) / col("median_price"))
      .withColumn("share_pct", col("n") / lit(total) * 100.0)
      .withColumn("rank_pct", percent_rank().over(Window.orderBy(col("n"))))
      .withColumn("inventory_level",
        when(col("rank_pct") >= 0.90, "very_high").when(col("rank_pct") >= 0.65, "high")
          .when(col("rank_pct") >= 0.30, "medium").otherwise("low"))
      .drop("rank_pct")
  }

  def brands(clean: DataFrame, makeDep: DataFrame): DataFrame = {
    val rates = makeDep.filter(col("dep_rate").isNotNull && col("age").between(1, 12))
      .groupBy("make").agg(avg("dep_rate").as("avg_dep_rate"))
    clean.groupBy("make")
      .agg(count(lit(1)).as("n"), pct("price", 0.5).as("median_price"), pct("age", 0.5).as("median_age"))
      .filter(col("n") >= 20)
      .withColumn("brand_tier", FeatureEngineering.tier(col("median_price")))
      .join(rates, Seq("make"), "left")
  }
}
