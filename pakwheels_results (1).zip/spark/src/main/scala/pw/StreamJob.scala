package pw

import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * Real-time listing screening with Spark Structured Streaming.
 *
 * Flow: API writes one JSON file per new listing into INCOMING_PATH (local dir or s3a:// / gs:// bucket)
 *       -> this job picks it up every few seconds -> cleans + scores it against the latest comps
 *       -> upserts into listings_scored, where the frontend's moderation queue reads it.
 *
 * To use Kafka/Kinesis/PubSub instead of files, replace the readStream source below; everything after it is unchanged.
 */
object StreamJob {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("pakwheels-stream").getOrCreate()
    spark.sparkContext.setLogLevel("WARN")

    val events = spark.readStream
      .schema(Clean.eventSchema)
      .option("maxFilesPerTrigger", "50")
      .json(Config.incomingPath)

    val query = Clean.normalize(events).writeStream
      .foreachBatch { (batch: org.apache.spark.sql.Dataset[org.apache.spark.sql.Row], batchId: scala.Long) =>
        if (!batch.isEmpty) {
          // Reload comps every micro-batch so a fresh batch run is picked up without restarting the stream.
          val comps = Sink.read(spark, "comps")
          val scored = Scoring.score(batch.dropDuplicates("listing_id"), comps, Config.minComps).cache()
          Sink.upsertScored(scored)
          println(s"batch $batchId: scored ${scored.count()} new listings")
          scored.unpersist(); ()
        }
      }
      .option("checkpointLocation", Config.checkpointPath)
      .trigger(Trigger.ProcessingTime("5 seconds"))
      .start()

    query.awaitTermination()
  }
}
