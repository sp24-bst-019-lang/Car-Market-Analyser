package pw

import org.apache.spark.ml.Transformer
import org.apache.spark.ml.classification.RandomForestClassifier
import org.apache.spark.ml.evaluation.{MulticlassClassificationEvaluator, RegressionEvaluator}
import org.apache.spark.ml.feature.VectorAssembler
import org.apache.spark.ml.linalg.Vector
import org.apache.spark.ml.regression.{GBTRegressionModel, GBTRegressor, RandomForestRegressionModel, RandomForestRegressor}
import org.apache.spark.ml.tree.{ContinuousSplit, InternalNode, LeafNode, Node}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * Step 5 (proposal: 05_model_training). Spark MLlib.
 *
 * 1. Regression: Random Forest and Gradient-Boosted Trees predict ln(price). Both are scored on the same 20% holdout,
 *    next to the simple "median of comparable listings" baseline. The best model is retrained on all rows and
 *    exported as JSON (trees + weights) into ml_models, so the API can predict in microseconds without Spark.
 * 2. Classification: a Random Forest classifier labels a listing below / at / above market from its asking price and
 *    basic specs. Labels come from peer comparison, so this is a "price position" model, NOT a sales-speed model:
 *    the data has no sold/expired information. Reported with a majority-class baseline for honesty.
 *
 * Everything is written to ml_models (metrics are JSON text) together with enc_stats (feature statistics).
 */
object ModelTraining {

  private val Label = "label"
  private val ClsLabel = "cls_label"
  private val ClsFeatures = Seq("ln_price", "enc_make", "model_year", "ln_mileage", "usage_intensity",
    "engine_cc", "fuel_code", "assembly_code", "brand_tier")

  private case class Scores(name: String, rmse: Double, r2: Double, mdape: Double, p90: Double)

  // ---- helpers --------------------------------------------------------------------------------

  private def assemble(df: DataFrame, cols: Seq[String]): DataFrame =
    new VectorAssembler().setInputCols(cols.toArray).setOutputCol("features").setHandleInvalid("skip").transform(df)

  /** JSON-safe number (NaN / Infinity become null). */
  private def num(d: Double): String = if (d.isNaN || d.isInfinity) "null" else d.toString

  private def q(s: String): String = "\"" + s + "\""

  private def medianAndP90(df: DataFrame, apeCol: String): (Double, Double) = {
    val r = df.agg(
      expr(s"percentile_approx($apeCol, 0.5, 1000)").as("md"),
      expr(s"percentile_approx($apeCol, 0.9, 1000)").as("p90")).head()
    (r.getDouble(0), r.getDouble(1))
  }

  private def evaluate(name: String, model: Transformer, test: DataFrame): Scores = {
    val p = model.transform(test)
      .withColumn("pred_price", exp(col("prediction")))
      .withColumn("ape", abs(col("pred_price") - col("price")) / col("price"))
      .cache()
    val ev = new RegressionEvaluator().setLabelCol(Label).setPredictionCol("prediction")
    val rmse = ev.setMetricName("rmse").evaluate(p)
    val r2 = ev.setMetricName("r2").evaluate(p)
    val (md, p90) = medianAndP90(p, "ape")
    p.unpersist()
    Scores(name, rmse, r2, md, p90)
  }

  // ---- tree export ----------------------------------------------------------------------------
  // Node format: leaf {"v": value}; split {"f": featureIndex, "t": threshold, "l": left, "r": right}.
  // MLlib sends a row left when feature <= threshold. api/src/ml.js evaluates this format.

  private def nodeJson(n: Node): String = n match {
    case i: InternalNode =>
      val s = i.split.asInstanceOf[ContinuousSplit]
      "{\"f\":" + s.featureIndex + ",\"t\":" + num(s.threshold) + ",\"l\":" + nodeJson(i.leftChild) +
        ",\"r\":" + nodeJson(i.rightChild) + "}"
    case l: LeafNode => "{\"v\":" + num(l.prediction) + "}"
  }

  private def exportModel(model: Transformer, refYear: Int): (String, Vector) = {
    val (roots, weights, importances): (Array[Node], Array[Double], Vector) = model match {
      case m: GBTRegressionModel => (m.trees.map(_.rootNode), m.treeWeights, m.featureImportances)
      case m: RandomForestRegressionModel =>
        val n = m.trees.length
        (m.trees.map(_.rootNode), Array.fill(n)(1.0 / n), m.featureImportances)
      case other => throw new IllegalArgumentException(s"cannot export ${other.getClass.getName}")
    }
    val json = "{\"target\":\"ln_price\",\"ref_year\":" + refYear + ",\"k\":" + FeatureEngineering.K +
      ",\"features\":[" + FeatureEngineering.Features.map(q).mkString(",") + "]" +
      ",\"weights\":[" + weights.map(num).mkString(",") + "]" +
      ",\"trees\":[" + roots.map(nodeJson).mkString(",") + "]}"
    (json, importances)
  }

  // ---- main entry -----------------------------------------------------------------------------

  def run(spark: SparkSession, training: DataFrame): Unit = {
    import spark.implicits._

    val base = FeatureEngineering.addBasic(training).cache()
    val nAll = base.count()
    val refYear = base.select(max(year(col("post_date")))).head().getInt(0)

    // ---------- 1. regression: honest holdout comparison ----------
    val Array(trn, tst) = base.randomSplit(Array(0.8, 0.2), 42L)
    val statsTr = FeatureEngineering.buildStats(trn).cache()
    val withLabel = (d: DataFrame) => d.withColumn(Label, log(col("price").cast("double")))
    val trE = assemble(withLabel(FeatureEngineering.encode(trn, statsTr, loo = true)), FeatureEngineering.Features).cache()
    val teE = assemble(withLabel(FeatureEngineering.encode(tst, statsTr, loo = false)), FeatureEngineering.Features).cache()
    val nTest = teE.count()

    def newGbt = new GBTRegressor().setLabelCol(Label).setFeaturesCol("features")
      .setMaxIter(80).setMaxDepth(6).setMaxBins(128).setStepSize(0.1).setSubsamplingRate(0.8).setSeed(42L)
    def newRf = new RandomForestRegressor().setLabelCol(Label).setFeaturesCol("features")
      .setNumTrees(40).setMaxDepth(8).setMaxBins(128).setSeed(42L)

    val results = Seq(
      evaluate("gbt", newGbt.fit(trE), teE),
      evaluate("random_forest", newRf.fit(trE), teE))
    val best = results.minBy(_.rmse)
    results.foreach(r => println(f"  ${r.name}%-14s rmse(log)=${r.rmse}%.4f r2=${r.r2}%.4f median APE=${r.mdape * 100}%.2f%% p90 APE=${r.p90 * 100}%.2f%%"))

    // Baseline: price a holdout car with the median of comparable listings built from the training split only.
    val compsTr = Comps.build(trn)
    val baseScored = Scoring.score(tst, compsTr, Config.minComps).filter(col("fair_price").isNotNull)
      .withColumn("ape", abs(col("fair_price") - col("price")) / col("price")).cache()
    val (bMd, bP90) = medianAndP90(baseScored, "ape")
    val bCoverage = baseScored.count().toDouble / math.max(nTest, 1L)
    println(f"  comps baseline median APE=${bMd * 100}%.2f%% p90 APE=${bP90 * 100}%.2f%% coverage=${bCoverage * 100}%.1f%%")

    // ---------- final regression model on all rows ----------
    val statsAll = FeatureEngineering.buildStats(base).cache()
    val allEnc = FeatureEngineering.encode(base, statsAll, loo = true)
    val allE = assemble(withLabel(allEnc), FeatureEngineering.Features)
    val finalModel: Transformer = if (best.name == "gbt") newGbt.fit(allE) else newRf.fit(allE)
    val (modelJson, importances) = exportModel(finalModel, refYear)

    val candJson = results.map(r =>
      "{\"name\":" + q(r.name) + ",\"rmse_log\":" + num(r.rmse) + ",\"r2\":" + num(r.r2) +
        ",\"mdape\":" + num(r.mdape) + ",\"p90_ape\":" + num(r.p90) + "}").mkString(",")
    val impJson = FeatureEngineering.Features.zip(importances.toArray)
      .map { case (f, v) => q(f) + ":" + num(v) }.mkString(",")
    val regMetrics = "{\"chosen\":" + q(best.name) + ",\"train_rows\":" + nAll + ",\"snapshot_year\":" + refYear +
      ",\"holdout\":{\"rows\":" + nTest + ",\"candidates\":[" + candJson + "]" +
      ",\"baseline_comps\":{\"mdape\":" + num(bMd) + ",\"p90_ape\":" + num(bP90) + ",\"coverage\":" + num(bCoverage) + "}}" +
      ",\"feature_importance\":{" + impJson + "}}"

    // ---------- 2. classification: below / at / above market ----------
    val compsAll = Comps.build(base)
    val labelled = Scoring.score(base, compsAll, Config.minComps)
      .filter(col("deal_ratio").isNotNull)
      .withColumn(ClsLabel,
        when(col("deal_ratio") < 0.90, 0.0).when(col("deal_ratio") <= 1.12, 1.0).otherwise(2.0))
      .withColumn("ln_price", log(col("price").cast("double")))
      .select("price", "make", "family", "model_year", "ln_price", "ln_mileage", "usage_intensity", "engine_cc",
        "fuel_code", "assembly_code", ClsLabel)
    val clsEnc = FeatureEngineering.encode(labelled, statsAll, loo = true)
    val Array(cTrain, cTest) = assemble(clsEnc, ClsFeatures).randomSplit(Array(0.8, 0.2), 7L)

    val rfc = new RandomForestClassifier().setLabelCol(ClsLabel).setFeaturesCol("features")
      .setNumTrees(60).setMaxDepth(8).setSeed(42L)
    val cModel = rfc.fit(cTrain)
    val cPred = cModel.transform(cTest).cache()
    val mce = new MulticlassClassificationEvaluator().setLabelCol(ClsLabel).setPredictionCol("prediction")
    val accuracy = mce.setMetricName("accuracy").evaluate(cPred)
    val f1 = mce.setMetricName("f1").evaluate(cPred)
    val cTotal = math.max(cPred.count(), 1L).toDouble
    val majority = cPred.groupBy(ClsLabel).count().agg(max("count")).head().getLong(0) / cTotal
    val confusion = cPred.groupBy(ClsLabel, "prediction").count().collect()
      .map(r => "{\"actual\":" + r.getDouble(0).toInt + ",\"predicted\":" + r.getDouble(1).toInt + ",\"n\":" + r.getLong(2) + "}")
      .mkString(",")
    val clsImp = ClsFeatures.zip(cModel.featureImportances.toArray)
      .map { case (f, v) => q(f) + ":" + num(v) }.mkString(",")
    val clsMetrics = "{\"classes\":[\"below_market\",\"at_market\",\"above_market\"],\"accuracy\":" + num(accuracy) +
      ",\"f1\":" + num(f1) + ",\"majority_baseline\":" + num(majority) + ",\"test_rows\":" + cTotal.toLong +
      ",\"confusion\":[" + confusion + "],\"feature_importance\":{" + clsImp + "}" +
      ",\"note\":\"Labels come from peer comparison (ask/fair < 0.90, 0.90-1.12, > 1.12). Sales speed is not in the data.\"}"
    println(f"  classifier accuracy=${accuracy * 100}%.1f%% f1=${f1}%.3f majority baseline=${majority * 100}%.1f%%")

    // ---------- save ----------
    CloudLoader.push(statsAll, "enc_stats")
    CloudLoader.push(Seq(
      ("price_regressor", modelJson, regMetrics),
      ("position_classifier", "", clsMetrics)).toDF("name", "model_json", "metrics"), "ml_models")
  }
}
