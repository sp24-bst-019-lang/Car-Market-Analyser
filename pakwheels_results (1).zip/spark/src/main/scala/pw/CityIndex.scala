package pw

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

/**
 * City price index: the median of (asking price / fair price) for listings in a city, using only
 * well-matched comparable groups (levels 1-2). 1.00 = market, 1.04 = asks run 4% above comparable cars.
 * Computed overall (make = '*') and per make. Small cities are dropped to avoid noisy numbers.
 *
 * Caveat: these are ASKING prices, and a city's own listings are part of each group's baseline,
 * so the index slightly understates real differences between cities.
 */
object CityIndex {
  def build(scored: DataFrame): DataFrame = {
    val base = scored
      .filter(col("comp_level").isin(1, 2) && col("deal_ratio").between(0.3, 3.0) && col("city").isNotNull)

    val med = expr("percentile_approx(deal_ratio, 0.5, 1000)").cast("double").as("price_index")

    val overall = base.groupBy("city").agg(count(lit(1)).as("n"), med)
      .filter(col("n") >= 100).withColumn("make", lit("*"))
    val byMake = base.groupBy("city", "make").agg(count(lit(1)).as("n"), med)
      .filter(col("n") >= 30)

    overall.select("city", "make", "n", "price_index")
      .unionByName(byMake.select("city", "make", "n", "price_index"))
  }
}
