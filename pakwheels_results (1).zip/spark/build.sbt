ThisBuild / scalaVersion := "2.12.18"
ThisBuild / version      := "0.1.0"

lazy val root = (project in file("."))
  .settings(
    name := "pakwheels-spark",
    libraryDependencies ++= Seq(
    "org.apache.spark" %% "spark-mllib" % "3.5.1",
      "org.apache.spark" %% "spark-sql"  % "3.5.1" % Provided,
      "org.postgresql"    % "postgresql" % "42.7.3"
    ),
    assembly / assemblyJarName := "pakwheels-spark.jar",
    assembly / assemblyMergeStrategy := {
      case PathList("META-INF", "services", _*) => MergeStrategy.concat
      case PathList("META-INF", _*)             => MergeStrategy.discard
      case _                                    => MergeStrategy.first
    }
  )
