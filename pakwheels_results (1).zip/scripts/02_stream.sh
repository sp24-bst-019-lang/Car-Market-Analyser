#!/usr/bin/env bash
# Start the Structured Streaming job that scores new listings dropped into INCOMING_PATH.
set -euo pipefail
cd "$(dirname "$0")/.."
set -a; source .env; set +a
mkdir -p "$INCOMING_PATH"
spark-submit --master "${SPARK_MASTER:-local[2]}" \
  --driver-memory "${STREAM_MEMORY:-2g}" \
  --conf spark.sql.shuffle.partitions=4 --conf spark.ui.enabled=false \
  --class pw.StreamJob spark/target/scala-2.12/pakwheels-spark.jar
