#!/usr/bin/env bash
# Start the API (it also serves the web app at http://localhost:3000).
set -euo pipefail
cd "$(dirname "$0")/.."
set -a; source .env; set +a
# Make the shared hand-off folder absolute: the API runs from api/, the Spark job from the project root,
# and a relative path would point them at two different folders.
export INCOMING_DIR="$(realpath -m "${INCOMING_DIR:-incoming}")"
cd api
[ -d node_modules ] || npm install --no-audit --no-fund
npm start
