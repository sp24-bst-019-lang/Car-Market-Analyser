#!/usr/bin/env bash
# Build the jar and run the whole Spark pipeline (ingest -> clean -> cloud DB -> score -> train -> insights).
set -euo pipefail
cd "$(dirname "$0")/.."
set -a; source .env; set +a
(cd spark && sbt -batch assembly)
spark-submit --master "${SPARK_MASTER:-local[*]}" \
  --driver-memory "${DRIVER_MEMORY:-4g}" \
  --conf spark.sql.shuffle.partitions=8 --conf spark.ui.enabled=false \
  --class pw.Main spark/target/scala-2.12/pakwheels-spark.jar
