# AutoVal-Intel: used-car valuation and market intelligence

Built on the PakWheels used-car listings (48,189 rows, Apr–May 2024).
**Apache Spark in Scala** (SQL, MLlib, Structured Streaming) does the data work, **PostgreSQL on Neon** is the cloud
database, and a small Node API plus a six-tab web app put the results in front of buyers, sellers and moderators.

## Run it in Google Colab

1. Create a free Postgres database at neon.tech (you need host, database name, user, password).
2. In Colab: **File → Upload notebook** and choose `colab/AutoVal_Intel_Colab.ipynb` (also provided separately).
3. Run the cells top to bottom. Cell 1 asks for this zip; Cell 4 asks for your database details.
   Cell 6 (the Spark pipeline) takes 10–20 minutes the first time; Cell 8 opens the app.

## Your proposal, module by module

| Proposal module | Scala file | What it does |
|---|---|---|
| 01 data ingestion | `Ingestion.scala` | loads the CSV with an explicit schema, writes a data-quality report |
| 02 preprocessing | `Preprocessing.scala`, `Clean.scala` | nulls, de-duplication, mileage/price outlier removal, encoding |
| 03 cloud loader | `CloudLoader.scala`, `Sink.scala` | pushes cleaned data and every result table to Postgres over JDBC |
| 04 feature engineering | `FeatureEngineering.scala` | model year, usage intensity, brand tier, smoothed make/model price encodings |
| 05 model training | `ModelTraining.scala` | MLlib Random Forest + GBT regression, Random Forest classification, exports the best model for the API |
| 06 market insights | `MarketInsights.scala` | depreciation curves, resale windows, market segments, brand summary |
| main.py | `Main.scala` | runs the six stages in order and logs timings |
| (real time) | `StreamJob.scala` | Structured Streaming: scores new listings within seconds |

Supporting code: `Comps.scala` + `Scoring.scala` (comparable-listing prices, deal labels, risk flags), `CityIndex.scala`, `Geo.scala`.

## The six tabs and the real problem each one solves

| Tab | Problem | How |
|---|---|---|
| **Price predictor** | "What is this car worth, and is this ad fair?" | Spark ML model and comparable listings side by side; the headline uses whichever had the lower error on the holdout |
| **Car finder & map** | "Where can I find this car, and where is it cheapest near me?" | filters + city map (size = listings, colour = median price), distance from your city, best deals first, risky listings hidden |
| **Depreciation & resale** | "How fast does it lose value, and when should I buy or sell?" | median price by age, yearly loss, the 3-year age window with the lowest loss |
| **Market insights** | "What is active, what do brands cost, which city is dearer?" | brand tiers, busiest models, city price index, supply by city and make |
| **Listing screening (live)** | "Is this new listing suspicious?" | API prices it instantly, Spark Structured Streaming flags it in seconds, moderation queue |
| **Pipeline & models** | "Can I trust these numbers?" | pipeline timings, data-quality report, model comparison vs. baseline, feature importance, classifier results |

## Where Spark is used, and why
- Cleaning, parsing, window functions, percentiles, joins: distributed Spark SQL, the same code scales to millions of rows.
- MLlib: the regression and classification models are trained and evaluated in Spark.
- Structured Streaming: the real-time listing scorer.
- Not used for the price check itself: Spark starts too slowly to answer a click, so the trained trees are exported as JSON
  and evaluated by the API in microseconds.

## Limits of the data (checked, not assumed)
- **No sales information.** There is no sold/expired status, so true "fast-selling" or demand forecasting is impossible.
  The classifier labels listings *below / at / above market price* (a price-position model), and "market activity" is
  listing volume. Both are labelled as proxies in the app.
- **No usable time series.** `post_date` ramps up because of how the listings were collected, so there are no price trends.
- **City level only.** The data has city names, not addresses, so the finder works per city (coordinates are approximate).
- **2024 prices.** Read results as "versus similar cars", not as today's absolute PKR.
- **No condition, trim or accident history.** Mileage turned out to add little within a model and year.
- **Risk flags are heuristics**, not proof of fraud; there are no fraud labels.
- Depreciation compares cars of different ages listed at the same time; it does not follow the same car over time.

## Status: read this first
Checked in the build environment:
- The pricing, ML-evaluator and API logic: 15 unit tests pass; every API route ran against stand-ins for Express/Postgres.
- The web app: loaded in a headless browser with canned API data, all six tabs rendered with no JavaScript errors.
- The comparable-listings method: a pandas prototype on the real CSV gave about 7% median error on a 5-fold holdout.

**Not checked: the Scala/Spark code has never been compiled or run** (no sbt, Spark or network in the build environment),
and the SQL was never run against a live Postgres. Expect to fix a typo or two on the first `sbt assembly`.
The ML accuracy numbers will appear in the app's *Pipeline & models* tab after the first run; I have not seen them.

## Run it elsewhere (optional)
Needs JDK 17, sbt, Spark 3.5.x, Node 18+. Copy `.env.example` to `.env`, run `sql/schema.sql` in your database, then
`scripts/01_pipeline.sh`, `scripts/02_stream.sh`, `scripts/03_api.sh` and open http://localhost:3000.
`SINK=parquet` writes Parquet files instead of using a database (for inspecting the pipeline output only).
To scale the live part, point `INCOMING_PATH`/`INCOMING_DIR` at a shared bucket (`s3a://`, `gs://`) or swap the `readStream` source in `StreamJob.scala` for Kafka.

## Tests
`cd api && npm test`
